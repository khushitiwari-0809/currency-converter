export const currencies = [
    {
        short: "USD",
        name: "Dolar amerykański",
        rate: 3.84,
    },

    {
        short: "EUR",
        name: "Euro",
        rate: 4.27,
    },

    {
        short: "GBP",
        name: "Funt brytyjski",
        rate: 5.07,
    },
];